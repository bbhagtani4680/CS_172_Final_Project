#include <iostream>
using namespace std;

class Person{
private:
    int age; 
    string sex;
    string city, state;
public: 
    // Default constructor
    Person();

    // Default constructor
    Person(int age, string sex, string city, string state);

    // To get the age of person
    int getAge();

    // To get the gender of the person
    string getsex();

    // To get the city of the person
    string getCity();

    // To get the state of the person
    string getState();
    
    // To set the age of the person
    void setAge(int age);

    // To set the gender of the person
    void setsex(string sex);

    // To set the city of the person
    void setCity(string city);

    // To get the state of the person
    void setState(string state);

};
