#include <iostream>
#include <fstream>
#include <vector>
#include "Person.h"
using namespace std;
class City{
private:string name;
        int totalCases; // To hold total number of cases
        int totalDeaths; //  To hold total number of deceased prople
        int totalRecoveries; //  To hold total number of recovered prople
        int activeCases; //  To hold total number of active prople
        Person person; // Person object to write into city
public: 
    City (string name); // Constructor for City
    City();// Default Constructor for CIty
    void addTotalCases(Person & P);// To add person into total cases file where each line is a patient
        
    void addToalDeaths(Person & P);// To add person into total deaths file where each line is a patient

    void addTotalRecoveries(Person & P); // To add person into total recoveries file where each line is a patient
    string getName(); //  To get the city's name
    int getTotalCases(); // To calculate the total cases

    int getTotalDeaths(); // To calculate the total deaths
    int getTotalRecoveries(); // To calculate the total recoveries

    int getActiveCases(); // To calculate the total active cases
    void setName(string _name); // To set the name of city

    //  getNum takes in a string argument which is the name of the file on which we want to work
    // It calculates the total number of lines as each line in the file is person.
    // Thus, returns number of lines or number of persons
    int getNum(string str);

    void print(); // To print the information of required city

};