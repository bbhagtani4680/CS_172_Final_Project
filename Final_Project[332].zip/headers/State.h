#include <iostream>
#include <vector>
#include "City.h"
using namespace std;
class State{
private:string name;
        int totalCases;
        int totalDeaths;
        int totalRecoveries;
        int activeCases;
        vector<City> cities;
        City city; // City object to work on cities in states
public: 
    // State Constructor
    State(string name);

    // Default Constructor
    State();

    // To get state's name
    string getName();

    // To set state's name
    void setName(string _name);

    // addCity reads the file with the name of cities and if the name of city is not present then it appends the city's name
    void addCity(string city);

    // getCities reads the file with city names and them add them to a City class vector to perform calculations
    void getCities();

    // getTotalCases adds cases from all cities in state to give total number in state
    int getTotalCases();

    // getTotalRecoveries adds recovered cases from all cities in state to give total number in state
    int getTotalRecoveries();

    // getTotalRecoveries adds deceased cases from all cities in state to give total number in state
    int getTotalDeaths();

    void print();
};