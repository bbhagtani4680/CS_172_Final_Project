#include "../headers/City.h"
City::City (string name){ // Constructor for City
    this->name= name;
}
City::City(){// Default Constructor for CIty
    name= "This City";
}

void City::addTotalCases(Person & P){ // To add person into total cases file where each line is a patient
    string str = "../dataFiles/Cities/" 
     name + ".txt"; // City specific file name  
    ofstream out; // object to write and append into city file
    out.open(str, ios::app);
    out << P.getAge() << " "<< P.getsex()<< " " << P.getCity()<<" " << P.getState() << endl; // fill into file
    out.close(); // close the file
}

void City::addToalDeaths(Person & P){// To add person into total deaths file where each line is a patient
    string str = "../dataFiles/Cities/" + name + "_Deaths.txt";// City specific file name
    ofstream out; // object to write and append into city file
    out.open(str, ios::app);
    out << P.getAge() << " "<< P.getsex()<< " " << P.getCity()<<" " << P.getState() << endl; //fill into file
    out.close(); //close the file
}

void City::addTotalRecoveries(Person & P){// To add person into total recoveries file where each line is a patient
    string str = "../dataFiles/Cities/" + name + "_Recoveries.txt";// City specific file name 
    ofstream out; // object to write and append into city file
    out.open(str, ios::app);
    out << P.getAge() << " "<< P.getsex()<< " " << P.getCity()<<" " << P.getState() << endl; // file into file
    out.close(); // close the file
}

string City::getName(){ //  To get the city's name
    return name; // return the name
}

int City::getTotalCases(){ // To calculate the total cases
    string str = "../dataFiles/Cities/" + name + ".txt";
    return getNum(str);
}

int City::getTotalDeaths(){ // To calculate the total deaths
    string str = "../dataFiles/Cities/" + name + "_Deaths.txt";
    return getNum(str);

}

int City::getTotalRecoveries(){ // To calculate the total recoveries
    string str = "../dataFiles/Cities/" + name + "_Recoveries.txt";        
    return getNum(str);
}

int City::getActiveCases(){ // To calculate the total active cases
    return getTotalCases() - getTotalRecoveries() - getTotalDeaths();
}

void City::setName(string _name){ // To set the name of city
    name = _name;
}

//  getNum takes in a string argument which is the name of the file on which we want to work
// It calculates the total number of lines as each line in the file is person.
// Thus, returns number of lines or number of persons

int City::getNum(string str){
    int num = 0; // intialilize with 0
    string p; // to hold person
    ifstream in(str); // Object to read the file
    if (in.is_open()){ // if the file opens or the data for the particular city exists
        while(!in.eof()){ // read till the end of file
            getline(in, p); // Read line
            num++; // add one person to total
        }
        in.close(); // close the file as the work is done
        return num-1; // return the number of lines and leave the last blank line
    }
    else{ // if file doesn't open or city doesn't exists
        return 0; // 0 as default number of cases
    }
}

void City::print(){ // To print the information of required city
    totalCases = getTotalCases(); // Get total number of cases
    totalRecoveries = getTotalRecoveries();// Get total number of recoveries
    totalDeaths= getTotalDeaths(); // Get total number of deaths
    activeCases = totalCases - totalRecoveries- totalDeaths; //  calculate active cases
    // print the details
    cout << "\nTotal number of cases: " <<totalCases <<endl;
    cout << "Total number of Recoveries: " <<totalRecoveries <<endl;
    cout << "Total number of Death: " <<totalDeaths <<endl;
    cout << "Total number of Active Cases: " <<activeCases <<endl;
}
