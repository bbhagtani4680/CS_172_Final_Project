#include <iostream>
#include "../headers/State.h" // it includes all the required files
using namespace std;

int main(){
    City city; // city object to work on cities
    State state; // city object to work on states
    int age; 
    string sex;
    string cc, ss;// cc will hold city name, and ss will hold states name
    int response, activity; 

    cout << "Welcome to covid-19 portal " << endl; // welcome prompt
    // ask if user want to enter data or get data
    cout << "Enter your choice:\n1: To update directory\n2: To get statistics" << endl;
    cin >> response;

    if(response==1){ // if user wants to update data
        cout << "Welcome to covid-19 update portal" << endl; // Welcome prompt
    }

    while (response==1){ 
        cout << "Enter your choice:\n1: Tested Positive\n2: Recovered\n3: Deceased\n4: Exit" << endl;
        cin >> activity;
        if(activity == 4){ // if user wants to exit
            break;
        }
        // line 28-36 to get data from user
        cout << "Enter age: ";
        cin >> age;
        cout << "Enter sex(F/M): ";
        cin >> sex;
        cout << "Enter city: ";
        cin >> cc;
        cout << "Enter state: ";
        cin >> ss;
        

        city = City(cc); 
        state = State(ss);
        state.addCity(cc); // add city to the given state
        Person p = Person(age,sex,cc,ss); // create person with given input

        if (activity == 1){ // if user wants to enter new case
            city.addTotalCases(p);
        }
        if (activity == 2){ // if user wants to enter recovered case
            city.addTotalRecoveries(p);
        }
        if (activity == 3){ // if user wants to enter deceased case
            city.addToalDeaths(p);
        }

    }
    while (response == 2){ // if user wants to get data

        cout << "Enter your choice:\n1: City\n2: State\n3: Exit "<<endl;
        cin >> activity;

        if (activity == 1){ // if user wants to get data by city
            cout << "Enter name of city: ";
            cin >> cc;
            city = City(cc);
            city.print();     
        }
        if (activity == 2){ // if user wants to get data by state
            cout << "Enter name of state: ";
            cin >> ss;
            state = State(ss);
            state.print();   
        }
        if(activity == 3){ // if user wants to get data by exit
            break;
        }
    }  
}