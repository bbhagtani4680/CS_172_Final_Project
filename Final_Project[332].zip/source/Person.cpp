#include "../headers/Person.h"

// Default constructor
Person::Person (){
    age = 35;
    sex = "Male";
    city = "This City";
    state = "This State";
}

// Default constructor
Person::Person(int age, string sex, string city, string state){ 
    this->age= age;
    this->sex = sex;
    this->city= city;
    this->state= state;
}
// To get the age of person
int Person::getAge(){
    return age;
}
// To get the gender of the person
string Person::getsex(){
    return sex;
}

// To get the city of the person
string Person::getCity(){
    return city;
}

// To get the state of the person
string Person::getState(){
    return state;
}

// To set the age of the person
void Person::setAge(int age){
    this-> age = age;
}
// To set the gender of the person
void Person::setsex(string sex){
    this->sex = sex;
}
// To set the city of the person
void Person::setCity(string city){
    this->city = city;
}
// To get the state of the person
void Person::setState(string state){
    this->state = state;
}
