#include "../headers/State.h"

// State Constructor
State::State(string name){ 
    this->name= name;
}

// Default Constructor
State::State(){ 
    name= "Unknown State";
}

// To get state's name
string State::getName(){ 
    return name;
}

// To set state's name
void State::setName(string _name){
    name = _name;
}

// addCity reads the file with the name of cities and if the name of city is not present then it appends the city's name
void State::addCity(string city){

    string cityName;
    bool found = false; // Intially consider it as not found
    string str = "../dataFiles/States/" + name + "_Cities.txt"; // file name that contains cities
    ofstream out(str, ios::app); // open it to write into the file 
    ifstream in(str); // open it to read aswell
    while(!in.eof()){ // till it reaches ends
        in >> cityName; // read the name of city
        if(cityName == city){ // if the match is found
            found = true; // turn found to true
            out.close(); //close the file
            in.close(); //close the file
            break; // exit the program as it is already there
        }
    }
    if (found==false){ // of match not found
        out << city << endl; // append it to the end
        out.close(); //close the file
    }   
} 

// getCities reads the file with city names and them add them to a City class vector to perform calculations
void State::getCities(){ 
    string str = "../dataFiles/States/" + name + "_Cities.txt"; // open file which contains names of cities
    string _city; // To hold city name extracted from file
    ifstream in(str); // open file to read
    while (!in.eof()){ // till it reaches end
        in >> _city; // hold city name
        city= City(_city); // create a city object with _city
        cities.push_back(city); // append it to City class vector
    }  
}

// getTotalCases adds cases from all cities in state to give total numbers in state
int State::getTotalCases(){
    totalCases = 0; // initialize with 0 cases
    getCities(); // get the name of cities 
    for(int i =0; i<cities.size()-1; i++){ // loop into each city
        totalCases+=cities.at(i).getTotalCases(); // add total cases of all cities
    } 
    return totalCases; // return total cases
}

// getTotalCases adds cases from all cities in state to give total numbers in state
int State::getTotalRecoveries(){
    totalRecoveries = 0;// initialize with 0 cases
    getCities(); // get the name of cities 
    for(int i =0; i<cities.size()-1; i++){ // loop into each city
        totalRecoveries+=cities.at(i).getTotalRecoveries();// add total recoveries from all cities
    }
    return totalRecoveries; // return total recoveries
}

int State::getTotalDeaths(){
    totalDeaths = 0;// initialize with 0 cases
    getCities(); 
    for(int i =0; i<cities.size()-1; i++){ // loop into each city
        totalDeaths+=cities.at(i).getTotalDeaths(); // add total number of deceased people of all cities
    }
    return totalDeaths; // return total of deceased people
}

void State::print(){
    totalCases = getTotalCases();
    totalRecoveries = getTotalRecoveries();
    totalDeaths= getTotalDeaths();
    activeCases = totalCases - totalRecoveries- totalDeaths;
    cout << "\nTotal number of cases: " <<totalCases <<endl;
    cout << "Total number of Recoveries: " <<totalRecoveries <<endl;
    cout << "Total number of Death: " <<totalDeaths <<endl;
    cout << "Total number of Active Cases: " <<activeCases <<endl;
}
